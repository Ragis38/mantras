import { z } from 'zod';
import { insertPujaSchema, insertMantraSchema, pujas, mantras } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  pujas: {
    list: {
      method: 'GET' as const,
      path: '/api/pujas' as const,
      responses: {
        200: z.array(z.custom<typeof pujas.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/pujas/:id' as const,
      responses: {
        200: z.custom<typeof pujas.$inferSelect & { mantras: typeof mantras.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
  },
  mantras: {
    list: {
      method: 'GET' as const,
      path: '/api/mantras' as const,
      input: z.object({
        pujaId: z.coerce.number().optional(),
        search: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof mantras.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/mantras/:id' as const,
      responses: {
        200: z.custom<typeof mantras.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
  },
  ai: {
    explain: {
      method: 'POST' as const,
      path: '/api/ai/explain' as const,
      input: z.object({
        mantraId: z.number(),
        question: z.string(),
      }),
      responses: {
        200: z.object({
          explanation: z.string(),
        }),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
        500: errorSchemas.internal,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type PujaResponse = z.infer<typeof api.pujas.get.responses[200]>;
export type PujasListResponse = z.infer<typeof api.pujas.list.responses[200]>;
export type MantraResponse = z.infer<typeof api.mantras.get.responses[200]>;
export type MantrasListResponse = z.infer<typeof api.mantras.list.responses[200]>;
export type AiExplainInput = z.infer<typeof api.ai.explain.input>;
export type AiExplainResponse = z.infer<typeof api.ai.explain.responses[200]>;

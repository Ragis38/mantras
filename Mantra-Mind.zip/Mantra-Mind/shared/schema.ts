import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

export const pujas = pgTable("pujas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
});

export const mantras = pgTable("mantras", {
  id: serial("id").primaryKey(),
  pujaId: integer("puja_id").references(() => pujas.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  sanskrit: text("sanskrit").notNull(),
  transliteration: text("transliteration").notNull(),
  meaning: text("meaning").notNull(),
  usageContext: text("usage_context").notNull(),
  audioUrl: text("audio_url"),
});

export const insertPujaSchema = createInsertSchema(pujas).omit({ id: true });
export const insertMantraSchema = createInsertSchema(mantras).omit({ id: true });

export type Puja = typeof pujas.$inferSelect;
export type InsertPuja = z.infer<typeof insertPujaSchema>;

export type Mantra = typeof mantras.$inferSelect;
export type InsertMantra = z.infer<typeof insertMantraSchema>;

export type PujaWithMantras = Puja & { mantras: Mantra[] };

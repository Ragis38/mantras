import { db } from "./db";
import { pujas, mantras, type Puja, type Mantra, type PujaWithMantras } from "@shared/schema";
import { eq, ilike } from "drizzle-orm";

export interface IStorage {
  getPujas(): Promise<Puja[]>;
  getPuja(id: number): Promise<PujaWithMantras | undefined>;
  getMantras(pujaId?: number, search?: string): Promise<Mantra[]>;
  getMantra(id: number): Promise<Mantra | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getPujas(): Promise<Puja[]> {
    return await db.select().from(pujas);
  }

  async getPuja(id: number): Promise<PujaWithMantras | undefined> {
    const [puja] = await db.select().from(pujas).where(eq(pujas.id, id));
    if (!puja) return undefined;

    const pujaMantras = await db.select().from(mantras).where(eq(mantras.pujaId, id));
    return { ...puja, mantras: pujaMantras };
  }

  async getMantras(pujaId?: number, search?: string): Promise<Mantra[]> {
    let query = db.select().from(mantras);
    let conditions = [];

    if (pujaId) {
      conditions.push(eq(mantras.pujaId, pujaId));
    }
    
    if (search) {
      conditions.push(ilike(mantras.title, `%${search}%`));
    }

    if (conditions.length > 0) {
      return await query.where(conditions[0]); // Using the first condition for simplicity in this lite example
    }

    return await query;
  }

  async getMantra(id: number): Promise<Mantra | undefined> {
    const [mantra] = await db.select().from(mantras).where(eq(mantras.id, id));
    return mantra;
  }
}

export const storage = new DatabaseStorage();

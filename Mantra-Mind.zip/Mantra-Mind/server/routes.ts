import type { Express } from "express";
import { type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { openai } from "./replit_integrations/audio/client"; 

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.get(api.pujas.list.path, async (req, res) => {
    const pujas = await storage.getPujas();
    res.json(pujas);
  });

  app.get(api.pujas.get.path, async (req, res) => {
    const puja = await storage.getPuja(Number(req.params.id));
    if (!puja) {
      return res.status(404).json({ message: "Puja not found" });
    }
    res.json(puja);
  });

  app.get(api.mantras.list.path, async (req, res) => {
    const pujaId = req.query.pujaId ? Number(req.query.pujaId) : undefined;
    const search = req.query.search as string | undefined;
    const mantras = await storage.getMantras(pujaId, search);
    res.json(mantras);
  });

  app.get(api.mantras.get.path, async (req, res) => {
    const mantra = await storage.getMantra(Number(req.params.id));
    if (!mantra) {
      return res.status(404).json({ message: "Mantra not found" });
    }
    res.json(mantra);
  });

  app.post(api.ai.explain.path, async (req, res) => {
    try {
      const input = api.ai.explain.input.parse(req.body);
      const mantra = await storage.getMantra(input.mantraId);
      
      if (!mantra) {
        return res.status(404).json({ message: "Mantra not found" });
      }

      const prompt = `
      You are an expert in Indian spirituality and Sanskrit mantras.
      The user is asking about the following mantra:
      Title: ${mantra.title}
      Sanskrit: ${mantra.sanskrit}
      Transliteration: ${mantra.transliteration}
      General Meaning: ${mantra.meaning}
      Usage Context: ${mantra.usageContext}

      User's Question: ${input.question}

      Provide a helpful, respectful, and culturally accurate answer.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-5.2",
        messages: [{ role: "user", content: prompt }],
      });

      res.json({ explanation: response.choices[0]?.message?.content || "I couldn't generate an explanation." });

    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      console.error("AI Error:", err);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Call the seed function
  await seedDatabase();

  return httpServer;
}

export async function seedDatabase() {
  const pujas = await storage.getPujas();
  if (pujas.length === 0) {
    const { db } = await import("./db");
    const { pujas, mantras } = await import("@shared/schema");

    const newPujas = await db.insert(pujas).values([
      {
        name: "Ganesh Chaturthi",
        description: "A festival celebrating the birth of Lord Ganesha, the remover of obstacles.",
      },
      {
        name: "Diwali Lakshmi Puja",
        description: "The main ritual during the festival of lights, honoring Goddess Lakshmi for wealth and prosperity.",
      }
    ]).returning();

    await db.insert(mantras).values([
      {
        pujaId: newPujas[0].id,
        title: "Vakratunda Mahakaya",
        sanskrit: "वक्रतुण्ड महाकाय सूर्यकोटि समप्रभ। निर्विघ्नं कुरु मे देव सर्वकार्येषु सर्वदा॥",
        transliteration: "Vakratunda Mahakaya Suryakoti Samaprabha, Nirvighnam Kuru Me Deva Sarvakaryeshu Sarvada.",
        meaning: "O Lord with the curved trunk and immense body, whose brilliance equals a million suns, I pray to you to remove the obstacles from all my endeavors, always.",
        usageContext: "Chanted at the beginning of any new task or the start of the Ganesh Puja to seek blessings for an obstacle-free completion."
      },
      {
        pujaId: newPujas[0].id,
        title: "Om Gam Ganapataye Namaha",
        sanskrit: "ॐ गं गणपतये नमः",
        transliteration: "Om Gam Ganapataye Namaha",
        meaning: "I bow to the Lord of Ganas (Ganesha).",
        usageContext: "A foundational mantra often chanted 108 times during meditation or puja."
      },
      {
        pujaId: newPujas[1].id,
        title: "Mahalakshmi Ashtakam",
        sanskrit: "नमस्तेऽस्तु महामाये श्रीपीठे सुरपूजिते। शङ्खचक्रगदाहस्ते महालक्ष्मि नमोऽस्तुते॥",
        transliteration: "Namastestu Mahamaye Shree Pithe Sura Poojite, Shankha Chakra Gada Haste Maha Lakshmi Namostute.",
        meaning: "Salutations to the great illusion, the one who resides in Sri Peetha, worshipped by the gods. Salutations to Mahalakshmi, who holds a conch, discus, and mace.",
        usageContext: "Chanted while offering flowers or lighting lamps during the main Diwali Puja."
      }
    ]);
  }
}

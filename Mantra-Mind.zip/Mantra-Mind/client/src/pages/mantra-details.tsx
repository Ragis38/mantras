import { useMantra } from "@/hooks/use-mantras";
import { Layout } from "@/components/layout";
import { Link, useRoute } from "wouter";
import { Loader2, ArrowLeft, Quote, Info } from "lucide-react";
import { MantraPlayer } from "@/components/mantra-player";
import { AiAssistant } from "@/components/ai-assistant";
import { motion } from "framer-motion";

export default function MantraDetails() {
  const [, params] = useRoute("/mantra/:id");
  const id = parseInt(params?.id || "0");
  const { data: mantra, isLoading, error } = useMantra(id);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center items-center h-[80vh]">
          <Loader2 className="h-8 w-8 text-primary animate-spin" />
        </div>
      </Layout>
    );
  }

  if (error || !mantra) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center h-[60vh] text-center">
          <p className="text-muted-foreground mb-4">Mantra not found.</p>
          <Link href="/">
            <button className="px-6 py-2 bg-primary text-primary-foreground rounded-full">
              Go Home
            </button>
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <Link href={`/puja/${mantra.pujaId}`}>
          <button className="mb-8 flex items-center text-muted-foreground hover:text-primary transition-colors text-sm font-medium">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Puja
          </button>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-8 space-y-10">
            
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-3xl md:text-5xl font-serif font-bold text-foreground mb-4">
                {mantra.title}
              </h1>
              <div className="h-1 w-20 bg-primary rounded-full" />
            </motion.div>

            {/* Sanskrit Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-orange-50/30 border border-orange-100 rounded-3xl p-8 md:p-12 text-center relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />
              <Quote className="absolute top-6 left-6 h-8 w-8 text-primary/10 transform -scale-x-100" />
              
              <h2 className="text-2xl md:text-4xl leading-relaxed font-medium text-orange-950 mb-8 font-serif">
                {mantra.sanskrit}
              </h2>
              <p className="text-lg md:text-xl text-orange-800/80 font-medium italic">
                "{mantra.transliteration}"
              </p>
              
              <Quote className="absolute bottom-6 right-6 h-8 w-8 text-primary/10" />
            </motion.div>

            {/* Meaning & Context */}
            <div className="space-y-8">
              <section>
                <h3 className="text-xl font-serif font-bold mb-3 flex items-center text-foreground">
                  Translation & Meaning
                </h3>
                <p className="text-muted-foreground leading-relaxed text-lg border-l-4 border-secondary pl-6">
                  {mantra.meaning}
                </p>
              </section>

              <section className="bg-white p-6 rounded-2xl border border-border">
                <h3 className="text-lg font-serif font-bold mb-3 flex items-center text-foreground">
                  <Info className="h-5 w-5 text-primary mr-2" />
                  Usage Context
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {mantra.usageContext}
                </p>
              </section>
            </div>
            
            {/* Audio Player */}
            {mantra.audioUrl && (
              <MantraPlayer audioUrl={mantra.audioUrl} title={mantra.title} />
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-4 space-y-8">
            {/* AI Assistant Sticky Wrapper */}
            <div className="sticky top-24">
              <AiAssistant mantraId={mantra.id} mantraTitle={mantra.title} />
              
              <div className="mt-8 p-6 bg-gradient-to-br from-indigo-900 to-purple-900 rounded-2xl text-white shadow-xl overflow-hidden relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
                <h3 className="font-serif text-lg font-bold mb-2 relative z-10">Premium Guidance</h3>
                <p className="text-white/80 text-sm mb-4 relative z-10">
                  Get personalized Vedic astrology insights based on your mantras.
                </p>
                <button className="w-full py-2 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-lg text-sm font-medium transition-colors border border-white/10">
                  Coming Soon
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

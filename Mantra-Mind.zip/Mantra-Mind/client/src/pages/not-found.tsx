import { Link } from "wouter";
import { Layout } from "@/components/layout";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <Layout>
      <div className="min-h-[80vh] w-full flex items-center justify-center bg-background">
        <div className="text-center space-y-6 p-8 max-w-md">
          <div className="w-20 h-20 bg-orange-100 rounded-full flex items-center justify-center mx-auto">
            <AlertCircle className="h-10 w-10 text-orange-600" />
          </div>
          
          <h1 className="text-4xl font-serif font-bold text-foreground">404</h1>
          <p className="text-lg text-muted-foreground">
            The path you seek is not found. Perhaps it is time to return to the beginning.
          </p>
          
          <Link href="/">
            <button className="px-8 py-3 rounded-xl font-semibold bg-primary text-primary-foreground hover:bg-primary/90 transition-all hover:scale-105 shadow-lg shadow-orange-500/20">
              Return Home
            </button>
          </Link>
        </div>
      </div>
    </Layout>
  );
}

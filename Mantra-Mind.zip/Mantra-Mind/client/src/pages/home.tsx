import { usePujas } from "@/hooks/use-pujas";
import { Layout } from "@/components/layout";
import { PujaCard } from "@/components/puja-card";
import { Loader2, Search } from "lucide-react";
import { useState } from "react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: pujas, isLoading, error } = usePujas();
  const [search, setSearch] = useState("");

  const filteredPujas = pujas?.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Layout>
      {/* Hero Section */}
      <div className="relative py-20 lg:py-32 overflow-hidden">
        {/* Abstract spiritual background decoration */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-orange-100/40 rounded-full blur-3xl -z-10" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-foreground mb-6">
              Sacred Mantras for <br/>
              <span className="text-gradient-gold">Every Puja</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed font-light">
              Discover the spiritual essence of ancient Vedic chants. 
              Learn correct pronunciations, meanings, and rituals for peace and prosperity.
            </p>
          </motion.div>

          {/* Search Bar */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-xl mx-auto relative"
          >
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-orange-400 to-red-400 rounded-full blur opacity-20 group-hover:opacity-30 transition-opacity" />
              <div className="relative bg-white rounded-full shadow-lg border border-orange-100 flex items-center p-2 pl-6">
                <Search className="h-5 w-5 text-muted-foreground mr-3" />
                <input
                  type="text"
                  placeholder="Search for pujas (e.g., Ganesh, Diwali)..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="flex-grow bg-transparent border-none focus:ring-0 text-foreground placeholder:text-muted-foreground/60 h-10 outline-none"
                />
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Content Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="h-8 w-8 text-primary animate-spin" />
          </div>
        ) : error ? (
          <div className="text-center py-20 text-destructive">
            Failed to load pujas. Please try again later.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPujas?.map((puja, index) => (
              <PujaCard key={puja.id} puja={puja} index={index} />
            ))}
            {filteredPujas?.length === 0 && (
              <div className="col-span-full text-center py-20 text-muted-foreground">
                No pujas found matching your search.
              </div>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}

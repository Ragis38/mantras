import { usePuja } from "@/hooks/use-pujas";
import { Layout } from "@/components/layout";
import { Link, useRoute } from "wouter";
import { Loader2, ArrowLeft, BookOpen, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export default function PujaDetails() {
  const [, params] = useRoute("/puja/:id");
  const id = parseInt(params?.id || "0");
  const { data: puja, isLoading, error } = usePuja(id);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center items-center h-[80vh]">
          <Loader2 className="h-8 w-8 text-primary animate-spin" />
        </div>
      </Layout>
    );
  }

  if (error || !puja) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center h-[60vh] text-center px-4">
          <h2 className="text-2xl font-serif font-bold text-foreground mb-2">Puja Not Found</h2>
          <p className="text-muted-foreground mb-6">The puja you are looking for does not exist.</p>
          <Link href="/">
            <button className="px-6 py-2 bg-primary text-primary-foreground rounded-full hover:bg-primary/90 transition-colors">
              Go Back Home
            </button>
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Header Image */}
      <div className="relative h-[40vh] md:h-[50vh] w-full overflow-hidden">
        {/* stock image: spiritual ceremony indian puja altar */}
        <img
          src={puja.imageUrl || "https://images.unsplash.com/photo-1603217039640-afa96f113843?q=80&w=2070&auto=format&fit=crop"}
          alt={puja.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        
        <div className="absolute bottom-0 left-0 w-full p-6 md:p-12 max-w-7xl mx-auto">
          <Link href="/">
            <button className="mb-6 flex items-center text-white/80 hover:text-white transition-colors bg-black/20 hover:bg-black/40 px-4 py-2 rounded-full backdrop-blur-sm w-fit">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Pujas
            </button>
          </Link>
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-serif font-bold text-foreground mb-4 drop-shadow-sm"
          >
            {puja.name}
          </motion.h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Left Column: Description */}
          <div className="lg:col-span-1 space-y-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-border">
              <h3 className="text-xl font-serif font-bold mb-4 flex items-center">
                <BookOpen className="h-5 w-5 text-primary mr-2" />
                About this Puja
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {puja.description}
              </p>
            </div>
            
            <div className="bg-orange-50 p-6 rounded-xl border border-orange-100">
              <h4 className="font-medium text-orange-900 mb-2">Did you know?</h4>
              <p className="text-sm text-orange-800/80">
                Mantras are sacred sounds that when chanted with devotion can create powerful positive vibrations in your environment.
              </p>
            </div>
          </div>

          {/* Right Column: Mantras List */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-serif font-bold mb-8 flex items-center">
              <span className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-sans mr-3">
                {puja.mantras.length}
              </span>
              Sacred Mantras
            </h2>

            <div className="space-y-4">
              {puja.mantras.map((mantra, index) => (
                <motion.div
                  key={mantra.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link href={`/mantra/${mantra.id}`}>
                    <div className="group bg-white p-6 rounded-xl shadow-sm border border-border hover:border-primary/50 hover:shadow-soft-gold transition-all cursor-pointer flex justify-between items-center">
                      <div>
                        <h3 className="font-serif text-xl font-bold text-foreground mb-1 group-hover:text-primary transition-colors">
                          {mantra.title}
                        </h3>
                        <p className="text-sm text-muted-foreground line-clamp-1 font-sans">
                          {mantra.meaning}
                        </p>
                      </div>
                      <div className="bg-secondary p-2 rounded-full group-hover:bg-primary group-hover:text-white transition-all">
                        <ChevronRight className="h-5 w-5" />
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}

              {puja.mantras.length === 0 && (
                <div className="text-center py-12 bg-muted/20 rounded-2xl border border-dashed border-border">
                  <p className="text-muted-foreground">No mantras added for this puja yet.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

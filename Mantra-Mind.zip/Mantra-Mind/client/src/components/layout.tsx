import { Link, useLocation } from "wouter";
import { Flower2, Home, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen flex flex-col font-sans text-foreground">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 w-full glass-card border-b border-orange-100/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <Link href="/" className="flex items-center space-x-2 group">
              <div className="bg-primary/10 p-2 rounded-full group-hover:bg-primary/20 transition-colors">
                <Flower2 className="h-6 w-6 text-primary" />
              </div>
              <span className="font-serif text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-orange-600 to-red-600">
                Puja Mantras
              </span>
            </Link>
            
            <div className="flex items-center space-x-6">
              <Link href="/">
                <button className={cn(
                  "flex items-center space-x-1 text-sm font-medium transition-colors hover:text-primary",
                  location === "/" ? "text-primary" : "text-muted-foreground"
                )}>
                  <Home className="h-4 w-4" />
                  <span className="hidden sm:inline">Home</span>
                </button>
              </Link>
              <div className="h-4 w-px bg-border/50" />
              <button className="flex items-center space-x-1 text-sm font-medium text-muted-foreground hover:text-primary transition-colors">
                <Sparkles className="h-4 w-4" />
                <span className="hidden sm:inline">Daily Mantra</span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-orange-50/50 border-t border-orange-100 mt-20">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8 text-center">
          <Flower2 className="h-8 w-8 text-primary/30 mx-auto mb-4" />
          <p className="text-muted-foreground font-serif italic">
            "Om Sarve Bhavantu Sukhinah" - May all beings be happy.
          </p>
          <div className="mt-8 text-xs text-muted-foreground/60">
            © {new Date().getFullYear()} Puja Mantras AI. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useState } from "react";
import { useExplainMantra } from "@/hooks/use-mantras";
import { Sparkles, Send, Loader2, Bot } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface AiAssistantProps {
  mantraId: number;
  mantraTitle: string;
}

export function AiAssistant({ mantraId, mantraTitle }: AiAssistantProps) {
  const [question, setQuestion] = useState("");
  const [response, setResponse] = useState<string | null>(null);
  const { mutate, isPending } = useExplainMantra();

  const handleAsk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    mutate(
      { mantraId, question },
      {
        onSuccess: (data) => {
          setResponse(data.explanation);
        },
      }
    );
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-border overflow-hidden">
      <div className="bg-gradient-to-r from-orange-50 to-amber-50 p-6 border-b border-orange-100">
        <div className="flex items-center space-x-3">
          <div className="bg-white p-2 rounded-lg shadow-sm border border-orange-100">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-lg text-foreground">Spiritual Guide AI</h3>
            <p className="text-xs text-muted-foreground">Ask about meaning, pronunciation, or benefits</p>
          </div>
        </div>
      </div>

      <div className="p-6">
        <AnimatePresence mode="wait">
          {response ? (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="bg-orange-50/50 rounded-xl p-6 border border-orange-100 mb-6"
            >
              <div className="flex items-start space-x-4">
                <Bot className="h-6 w-6 text-primary mt-1 flex-shrink-0" />
                <div className="space-y-2">
                  <p className="text-sm font-medium text-orange-900/60">Answer to: "{question}"</p>
                  <p className="text-foreground leading-relaxed text-sm md:text-base">
                    {response}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => { setResponse(null); setQuestion(""); }}
                className="mt-4 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
              >
                Ask another question
              </button>
            </motion.div>
          ) : (
            <form onSubmit={handleAsk} className="relative">
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder={`Ask about ${mantraTitle}...`}
                className={cn(
                  "w-full pl-4 pr-14 py-4 rounded-xl bg-muted/30 border border-input",
                  "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary",
                  "placeholder:text-muted-foreground/60 transition-all shadow-inner"
                )}
                disabled={isPending}
              />
              <button
                type="submit"
                disabled={!question.trim() || isPending}
                className={cn(
                  "absolute right-2 top-2 h-10 w-10 rounded-lg flex items-center justify-center transition-all",
                  question.trim() && !isPending
                    ? "bg-primary text-primary-foreground hover:bg-primary/90 shadow-md"
                    : "bg-transparent text-muted-foreground cursor-not-allowed"
                )}
              >
                {isPending ? (
                  <Loader2 className="h-5 w-5 animate-spin" />
                ) : (
                  <Send className="h-5 w-5" />
                )}
              </button>
            </form>
          )}
        </AnimatePresence>
        
        {!response && (
          <div className="mt-4 flex flex-wrap gap-2">
            {["What is the meaning?", "When should I chant this?", "What are the benefits?"].map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => setQuestion(q)}
                className="text-xs bg-muted/50 hover:bg-primary/5 hover:text-primary px-3 py-1.5 rounded-full transition-colors border border-transparent hover:border-primary/20 text-muted-foreground"
              >
                {q}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

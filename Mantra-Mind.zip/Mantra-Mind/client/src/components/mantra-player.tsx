import { useState, useRef } from "react";
import { Play, Pause, Volume2 } from "lucide-react";

interface MantraPlayerProps {
  audioUrl?: string | null;
  title: string;
}

export function MantraPlayer({ audioUrl, title }: MantraPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  if (!audioUrl) return null;

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="mt-8 bg-orange-50/50 rounded-xl p-4 border border-orange-100 flex items-center justify-between shadow-sm">
      <div className="flex items-center space-x-4">
        <button
          onClick={togglePlay}
          className="h-12 w-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 hover:scale-105 transition-all shadow-lg shadow-orange-500/20 active:scale-95"
        >
          {isPlaying ? (
            <Pause className="h-5 w-5 fill-current" />
          ) : (
            <Play className="h-5 w-5 fill-current ml-1" />
          )}
        </button>
        <div>
          <p className="font-medium text-foreground text-sm">Play Mantra Audio</p>
          <p className="text-xs text-muted-foreground">{title} Recitation</p>
        </div>
      </div>

      <Volume2 className="h-5 w-5 text-muted-foreground/50" />
      
      <audio
        ref={audioRef}
        src={audioUrl}
        onEnded={() => setIsPlaying(false)}
        className="hidden"
      />
    </div>
  );
}

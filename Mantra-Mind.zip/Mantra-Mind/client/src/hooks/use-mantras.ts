import { useQuery, useMutation } from "@tanstack/react-query";
import { api, buildUrl, type AiExplainInput } from "@shared/routes";

export function useMantra(id: number) {
  return useQuery({
    queryKey: [api.mantras.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.mantras.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch mantra");
      return api.mantras.get.responses[200].parse(await res.json());
    },
    enabled: !!id,
  });
}

export function useExplainMantra() {
  return useMutation({
    mutationFn: async (data: AiExplainInput) => {
      const validated = api.ai.explain.input.parse(data);
      const res = await fetch(api.ai.explain.path, {
        method: api.ai.explain.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.ai.explain.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to get explanation");
      }
      
      return api.ai.explain.responses[200].parse(await res.json());
    },
  });
}

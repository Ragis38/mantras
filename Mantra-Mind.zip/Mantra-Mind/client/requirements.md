## Packages
framer-motion | Page transitions and animations
lucide-react | Icons
clsx | Class name utility
tailwind-merge | Class name utility

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  serif: ["Playfair Display", "serif"],
  sans: ["Lato", "sans-serif"],
}
Colors:
primary: 35 90% 50% (Saffron/Gold)
secondary: 15 40% 96% (Warm Cream)
